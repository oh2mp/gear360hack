cd /opt/usr/
tar xf /mnt/mmc/opt-usr.tar
chmod a+x bin/postinstall.sh
bin/postinstall.sh
