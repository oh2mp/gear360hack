#!/bin/sh

# Remove or comment out next line to disable ftp
/opt/usr/bin/tcpsvd -vE 0.0.0.0 21 ftpd -w /sdcard &
# Remove or comment out next line to disable telnet
LD_LIBRARY_PATH=/opt/usr/lib /opt/usr/bin/telnetd &

# This is vital. Do not touch unless you really know what you are doing.
LD_LIBRARY_PATH=/opt/usr/lib PERL5LIB=/opt/usr/lib/perl /opt/usr/bin/httpd -p 8000 -f -h /opt/usr/www &
